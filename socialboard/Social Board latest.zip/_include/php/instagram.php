<?php
     session_start();
     require 'instagram.class.php';
     
     // Setup class
     $instagram = new Instagram(array(
       'apiKey'      => '7e7e02c0d26c49e18f9c43e64de81288',
       'apiSecret'   => '6e019abb42b249909c7129e395fe32dd',
       'apiCallback' => 'http://ix.cs.uoregon.edu/~wcleary/index.php' // must point to success.php
     ));
     $token;
     $check;
     // Receive OAuth code parameter
     if(!isset( $_SESSION["check"] )&&strlen($_GET["code"])<50){
        $code = $_GET["code"];
        //echo "$code<br>";
        $_SESSION["check"] =$code;
    }
    $code=$_SESSION["check"];
    //echo "$code<br>";
    //echo strlen($code);
     //echo "$code<br>";

     // Check whether the user has granted access
     if (true === isset($code)&& strlen($code)<50) {
      //echo "true hit<br>";
       //echo "passed<br>";
       //$data = $instagram->getInstagramPhotos($code);
       //echo $data;
       // Receive OAuth token object
       if(!isset( $_SESSION[$token] ) ){ 
         //echo "session not set<br>";
           $data = $instagram->getOAuthToken($code);
           $_SESSION[$token] =$data;
           //echo "session = ".$_SESSION[$token];
            $instagram->setAccessToken($data);
         }else{
           $var=$_SESSION[$token];
           //echo "session = ".$_SESSION[$token];
           $instagram->setAccessToken($var);
         } 
       //echo "$token";
       // Store user access token
      
 
       // Now you can call all authenticated user methods
       // Get all user likes
       $likes = $instagram->getUserMedia();
       //print_r($likes);
       // Display all user likes
       foreach ($likes->data as $entry) {
          $text = "<p>".$entry->likes->count." likes</p>";
           foreach($entry->comments->data as $comments){
              $text = $text."<p><b><font color="."white".">".$comments->from->username."</font></b>  ".$comments->text."</p>";
           }
        $caption= addslashes($entry->caption->text);
        $text = addslashes($text);
        $text =  str_replace ( "\"", "&quot;", $text );
         echo '<script>
                 $( document ).ready(function() { 
                 $(\'.userFeed\').after(\'<li class="item-thumbs instagram"><a class="hover-wrap fancybox" data-fancybox-group="gallery" title= "'.$caption.'" href="'. $entry->images->standard_resolution->url.'"><span class="overlay-img"></span><span class="overlay-img-thumb font-icon-plus"></span></a><img id="instagram" src="'. $entry->images->thumbnail->url.'" alt="'.$text.'"></img>\');
                 });
               </script>';
       }
       

     } else {
         if (true === isset($_GET['error'])) {
           echo 'An error occurred: '.$_GET['error_description'];
         }else{
           $loginUrl = $instagram->getLoginUrl();
           echo '<script>
                   $( document ).ready(function() { 
                     $(\'.userFeed\').after(\'<li class="item-thumbs instagram"><a href="'. $loginUrl .'"><img src="./_include/img/instagram2.png" width = "250" height = "250"></img></a>\');
                   });
                 </script>';
         }
     }




     /*
     $data = $instagram->getOAuthToken("cca03323f2134982aa1bfb04fef0e1bf");
     $instagram->setAccessToken($data);
     //$instagram->setAccessToken('2411052.5f538ec.e9d4d308f3f6438dacbab08a0124c456');
     $likes = $instagram->getUserMedia();

       // Display all user likes
       foreach ($likes->data as $entry) {
         echo '<script>
                 $( document ).ready(function() { 
                 $(\'.userFeed\').after(\'<li class="item-thumbs instagram"><a href="'. $entry->images->thumbnail->url .'"><img src="'. $entry->images->thumbnail->url.'"></img></a>\');
                 });
               </script>';
       }*/
   ?>