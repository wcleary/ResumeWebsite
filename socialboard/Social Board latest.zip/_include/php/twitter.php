<?php

require_once('_include/php/twitteroauth/twitteroauth.php');
require_once('_include/php/config.php');

/* If access tokens are not available redirect to connect page. */
/* Get user access tokens out of the session. */
$access_token = $_SESSION['access_token'];

/* Create a TwitterOauth object with consumer/user tokens. */
$connection = new TwitterOAuth(CONSUMER_KEY, CONSUMER_SECRET, $access_token['oauth_token'], $access_token['oauth_token_secret']);

$userprof = $connection->get('account/verify_credentials');

/* If method is set change API call made. Test is called by default. */
$content = $connection->get('statuses/home_timeline',array('count'=>15, 'contributor_details'=>false, 'include_entities'=>false));
$login = '<a href="_include/php/redirect.php"><img src="_include/img/twitterLogin.png" alt="Sign in with Twitter" height="200" width="200"/></a>';
/* Some example calls */
//$connection->get('users/show', array('screen_name' => 'abraham'));
//$connection->post('statuses/update', array('status' => date(DATE_RFC822)));
//$connection->post('statuses/destroy', array('id' => 5437877770));
//$connection->post('friendships/create', array('id' => 9436992));
//$connection->post('friendships/destroy', array('id' => 9436992));

/* Include HTML to display on the page */

if(is_array($content)){
	foreach($content as $status){
			echo '<script>
                  $( document ).ready(function() { 
                  $(\'.twitterFeed\').after(\'<li class="item-thumbs span9 alert alert-info fade in Twitter"><img src="'.$status->user->profile_image_url_https.'" width:250px height:250px/img>  <b>'.$status->user->name.'</b> @'.$status->user->screen_name.'<p>'.$status->text.'</p><p><input type="button" value="Favorite" id="'.$status->id.'" onclick="$(this).favorite('.$status->id.');"/></p> \');
                  });
                </script>';
            }
}
else{
	echo '<script>
    $( document ).ready(function() { 
      $(\'.twitterFeed\').after(\'<li class="item-thumbs Twitter">'.$login.'</li>\');
    });
    </script>';
}