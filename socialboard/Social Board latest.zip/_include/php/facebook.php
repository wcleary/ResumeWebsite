<?php
 // Remember to copy files from the SDK's src/ directory to a
 // directory in your application on the server, such as php-sdk/
 require_once('php-sdk/facebook.php');

 $config = array(
   'appId' => '538244636260687',
   'secret' => 'f8d8b78a7494555a223e28e77ae77706',
 );

 $facebook = new Facebook($config);
  $user_id = $facebook->getUser();
   if($user_id) {

     // We have a user ID, so probably a logged in user.
     // If not, we'll get an exception, which we handle below.
     try {
       $user_profile = $facebook->api('/me/photos');
       //print_r ($user_profile);
      // $array = $user_profile['data'];
       //$first = $array['0'];
       //print_r ($first);
       foreach($user_profile['data'] as $entry){
         /*foreach($entry as $data)
           $length = count($data);
           echo  'length of array'.$length;
           print_r ($entry);
           echo '<img height="246" width="320" src="'. $entry['source'].'"></img>';*/
           $likes = 0;
           foreach($entry['likes'] as $count){
            $likes = $likes + 1;
           }
           if($likes === 0){$text = "";}
           else{$text = "<p>".$likes." likes</p>"; }
           foreach($entry['comments']['data'] as $comments){
              $text = $text."<p><b><font color=".'white'.">".$comments['from']['name']."</font></b>"."\t".$comments['message']."</p>";
           }
           $title = addslashes($entry['name']);
           echo ('<script>
                 $( document ).ready(function() { 
                 $(\'.fbFeed\').after(\'<li class="item-thumbs FaceBook"><a class="hover-wrap fancybox" data-fancybox-group="gallery" title="'.$title.'" href="'.$entry['source'].'"><span class="overlay-fbimg"></span><span class="overlay-img-thumb font-icon-plus"></span></a><img id ="facebook" src="'.$entry['source'].'" alt="'.$text.'"></img></a>\');
                 });
               </script>') ;



       }
       /*
         for ($x=0; $x<=10; $x++){
         echo '<script>
                 $( document ).ready(function() { 
                 $(\'.fbFeed\').after(\'<li class="item-thumbs FaceBook"><a href="'. $login_url .'"><img height="246" width="320" src="'. $first['source'].'"></img></a>\');
                 });
               </script>';
             }*/


       //echo '<img height="246" width="320" src="'. $first['source'].'"></img>';

     } catch(FacebookApiException $e) {
       // If the user is logged out, you can have a 
       // user ID even though the access token is invalid.
       // In this case, we'll get an exception, so we'll
       // just ask the user to login again here.
       $login_url = $facebook->getLoginUrl(); 
       echo 'Please <a href="' . $login_url . '">login.</a>';
       error_log($e->getType());
       error_log($e->getMessage());
     }   
   } else {

     // No user, print a link for the user to login
     $login_url = $facebook->getLoginUrl(array("scope" => "user_photos"));
   //echo '<a href="' . $login_url . '">login.</a>';
   echo '<script>
   $( document ).ready(function() { 
     $(\'.fbFeed\').after(\'<li class="item-thumbs FaceBook"><a href="'. $login_url .'"><img src="./_include/img/facebooklogo.png" width = "250" height = "250"></img></a>\');
   });
   </script>';
   }
   


 ?>