<?php

/**
 * @file
 * A single location to store configuration.
 */

define('CONSUMER_KEY', 'B5vJq36ky4vj6aixPaKwiA');
define('CONSUMER_SECRET', '1VX1I5zv2TyHMXD8m1VdfGf3g6F3oJkVbRarYCfWOY');
define('OAUTH_CALLBACK', 'ix.cs.uoregon.edu/~wcleary/_include/php/callback.php');
 