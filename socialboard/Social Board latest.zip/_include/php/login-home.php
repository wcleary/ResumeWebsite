<<?PHP
require_once("membersite_config.php");
if(!$fgmembersite->CheckLogin())
{
    $fgmembersite->RedirectToURL("login.php");
    exit;
}
	require_once('php-sdk/facebook.php');
	$config = array(
    'appId' => '352838394859685',
    'secret' => '18746228dc6053497ae9700db21cd4d5'
  );
  $facebook = new Facebook($config);
  $user_id = $facebook->getUser();
?>
<!DOCTYPE html>
<html>
<head>
      <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
      <title>Home page</title>
      <link rel="stylesheet" href="style/supersized.css">
       <link rel="STYLESHEET" href="style/style.css" />
      <script src="scripts/jquery-1.8.2.min.js"></script>
      <script src="scripts/supersized.3.2.7.min.js"></script>
      <script src="scripts/supersized-init.js"></script>
</head>
</head>
<body>
<div id='fg_membersite_content'>
<h2>Home Page</h2>
Welcome back <?= $fgmembersite->UserFullName(); ?>!<br>



<?PHP
if($user_id) {

      // We have a user ID, so probably a logged in user.
      // If not, we'll get an exception, which we handle below.
      try {

        $user_profile = $facebook->api('/me','GET');
        echo "Name: " . $user_profile['name']."<br>";
		$access_token = $facebook->getAccessToken();
		$fgmembersite->InsertFB($access_token);
		
      } catch(FacebookApiException $e) {
        // If the user is logged out, you can have a 
        // user ID even though the access token is invalid.
        // In this case, we'll get an exception, so we'll
        // just ask the user to login again here.
        $login_url = $facebook->getLoginUrl(); 
        echo 'Please <a href="' . $login_url . '">relogin.</a>';
        error_log($e->getType());
        error_log($e->getMessage());
      }   
    } else {

      // No user, print a link for the user to login
      $login_url = $facebook->getLoginUrl();
      echo 'Please <a href="' . $login_url . '">not one login.</a><br>';

    }
	if(isset($user_profile)){
		$check=$fgmembersite->CheckFB();
	echo "<br>check is empty = ".empty($check)."<br>";
	
	if(!empty($check)){
		echo "<br>Access_token:". $fgmembersite->CheckFB()."<br>";
		echo "<br>~~~~~Good, you login already~~~~~<br>";
		$search = $facebook->api('/me?fields=id,name&access_token='. $fgmembersite->CheckFB());
		print_r ($search);
		echo "<br><hr><br>";
		
		$search = $facebook->api('/me/feed?access_token='. $fgmembersite->CheckFB());
		
		
	
		foreach ($search['data'] as $entry){
	    	// If its a message posted by user
	    	$isStatusUpdate = array_key_exists('message', $entry) and $entry['from']['name'] == $profile['name'];
	
	    	if ($isStatusUpdate)
	    	{
	        	$likes = 0;
	        	$comment = 0;
	
	        	// Get num of likes 
	        	if (array_key_exists('likes', $entry))
	            	$likes = count($entry['likes']['data']); 
				
	        	// Get num of comments
	        	if (array_key_exists('comments', $entry))
	            	$comments = count($entry['comments']['data']);
				
	        	// Display message with num of likes and comments
	        	echo '<div class="row"><div class="span4 columns"><h2>Post '.$counter.'</h2>';
	        	echo '<p>Likes '.$likes.'</br>';
	        	echo 'Comments '.$comments.'</p></div>';
	        	echo '<div class="span12 columns"><h3>'.substr($entry['created_time'], 0, 10).'</h3>';
	        	echo '<pre class="prettyprint">'.$entry['message'].'</pre></div>';
	    	}
		}
		echo '<script>console.log('.json_encode($search).')</script>';

	}else{
		echo "<br>!!!!!!!You haven't login yet!!!!!!!!<br>";
	}
	}
	
?>
<p><a href='change-pwd.php'>Change password</a></p>

<p><a href='access-controlled.php'>A sample 'members-only' page</a></p>
<br><br><br>
<p><a href='logout.php'>Logout</a></p>
</div>
</body>
</html>
