    <?php
      session_start();
      require 'instagram.class.php';
      require 'instagram.php';
      
      // Setup class
      $instagram = new Instagram(array(
        'apiKey'      => '5f538ec0d0234bf99122d4dba3b9c0d5',
        'apiSecret'   => 'd81438f4304449ff81720bed93c1bce5',
        'apiCallback' => 'http://ix.cs.uoregon.edu/~wcleary/_include/php/instagram.php' // must point to success.php
      ));
      
      $loginUrl = $instagram->getLoginUrl();
            echo '<script>
                    $( document ).ready(function() { 
                      $(\'.userFeed\').after(\'<li class="item-thumbs instagram"><a href="'. $loginUrl .'"><img src="./_include/img/instagram2.png"></img></a>\');
                    });
                  </script>';
          }
    ?>