<?PHP
require_once("./include/fg_membersite.php");

$fgmembersite = new FGMembersite();

//Provide your site name here
$fgmembersite->SetWebsiteName('The Social Board');

//Provide the email address where you want to get notifications
$fgmembersite->SetAdminEmail('calvin1921@hotmail.com');

//Provide your database login details here:
//hostname, user name, password, database name and table name
//note that the script will create the table (for example, fgusers in this case)
//by itself on submitting register.php for the first time
$fgmembersite->InitDB(/*hostname*/'ix:3143',
                      /*username*/'kho3',
                      /*password*/'0000',
                      /*database name*/'accounts',
                      /*table name*/'Account_list');

//For better security. Get a random string from this link: http://tinyurl.com/randstr
// and put it here
$fgmembersite->SetRandomKey('qSRcVS6DrTzrPvr');

?>